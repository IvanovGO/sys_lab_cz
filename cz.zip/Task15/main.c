#include <stdio.h>
  int main(int argc, char ** argv){
  puts("Implementation of Task15");
  return 1;}
