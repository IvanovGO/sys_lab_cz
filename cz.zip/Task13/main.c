#include <stdio.h>
  int main(int argc, char ** argv){
  puts("Implementation of Task13");
  return 1;}
